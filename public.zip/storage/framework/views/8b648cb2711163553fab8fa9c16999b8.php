<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/global.css')); ?>">
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html><?php /**PATH E:\Project\PHP\Laravel\full-stack-dynamic-portfolio\resources\views\auth\layouts\auth.blade.php ENDPATH**/ ?>