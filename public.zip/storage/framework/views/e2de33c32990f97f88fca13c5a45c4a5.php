<link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">



<?php $__env->startSection('content'); ?>
    <div class="login-wrapper">
        <div class="login-card">
            
            <div class="login-header">
                <div class="brand-logo">R</div>
                <h2>Welcome Back</h2>
                <p>Enter your credentials to access the admin panel.</p>
            </div>

            <form action=<?php echo e(route("login")); ?> method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="amin22205101245@diu.edu.bd" required autofocus>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                </div>

                <div class="form-actions">
                    <label class="checkbox-container">
                        <input type="checkbox" name="remember">
                        <span class="checkmark"></span>
                        Remember me
                    </label>
                    <a href="#" class="forgot-link">Forgot Password?</a>
                </div>

                <button type="submit" class="btn-login">Sign In</button>
            </form>
            
            <div class="login-footer">
                <p>&copy; <?php echo e(date('Y')); ?> Admin Panel. Secure Access Only.</p>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project\PHP\Laravel\full-stack-dynamic-portfolio\resources\views\auth\pages\login.blade.php ENDPATH**/ ?>