<link rel="stylesheet" href="<?php echo e(asset('assets/css/projects.css')); ?>">

<section id="projects" class="projects-section">
    <div class="container">
        <div class="section-header">
            <span class="sub-headline">My Work</span>
            <h2>Featured <span class="highlight">Projects</span></h2>
            <p>A selection of my recent full-stack development work.</p>
        </div>

        <div class="projects-grid">
            
            
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="project-card">
                    <div class="card-image">
                        <img 
                            src="<?php echo e(asset('storage/' . $project->image_path)); ?>" 
                            alt="<?php echo e($project->title); ?>"
                        >
                    </div>

                    <div class="card-content">
                        <h3><?php echo e($project->title); ?></h3>

                        <p><?php echo e(Str::limit($project->description, 150)); ?></p>

                        <div class="tech-stack">
                            <?php $__currentLoopData = explode(',', $project->technology_used ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(trim($tech) !== ''): ?>
                                    <span><?php echo e(trim($tech)); ?></span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="card-actions">
                            <a 
                                href="<?php echo e($project->live_view_url ?? '#'); ?>" 
                                class="btn-link" 
                                target="_blank"
                            >
                                View Live <i class="arrow-icon">→</i>
                            </a>

                            <a 
                                href="<?php echo e($project->github_link ?? '#'); ?>" 
                                class="github-link" 
                                target="_blank"
                            >
                                GitHub
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH E:\Project\PHP\Laravel\full-stack-dynamic-portfolio\resources\views\components\projects.blade.php ENDPATH**/ ?>