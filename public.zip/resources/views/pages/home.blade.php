@extends('layouts.main')

@section('content')
    

    @include("components.hero")
    @include("components.about")
    @include("components.projects")
    @include("components.contact")

@endsection